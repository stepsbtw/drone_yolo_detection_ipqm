import cv2
import numpy as np
from pathlib import Path
from ultralytics import YOLO

try:
    from drone_people_detector.core.tracks import PersonTrack, TrackManager
except ImportError:
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from .tracks import PersonTrack, TrackManager

from drone_people_detector.core.camera import Camera
from drone_people_detector.core.weapon_detector import WeaponDetector
from drone_people_detector.core.monocular_vision_submodule import MonocularVision


class DetectionStatistics:
    def __init__(self):
        self.total_people_detected = 0
        self.total_weapons_detected = 0
        self.frames_with_people = 0
        self.frames_with_weapons = 0
        self.unique_people_tracked = 0


class Detector:
    """detector de pessoas com tracking e deteccao de armas"""
    
    def __init__(self, model_path, confidence_threshold=0.5, 
                 enable_weapon_detection=True, weapon_confidence_threshold=0.2,
                 weapon_model_path='models/weapons/yolov8guns.pt',
                 sample_majority_threshold=1, enable_tracking=True,
                 show_weapon_bbox=False, use_temporal_voting=True):
        
        self.model = YOLO(model_path)
        self.confidence_threshold = confidence_threshold
        
        self.enable_weapon_detection = enable_weapon_detection
        self.weapon_confidence_threshold = weapon_confidence_threshold
        self.sample_majority_threshold = sample_majority_threshold
        self.show_weapon_bbox = show_weapon_bbox
        self.use_temporal_voting = use_temporal_voting
        
        if self.enable_weapon_detection:
            self.weapon_detector = WeaponDetector(
                model_path=weapon_model_path,
                confidence_threshold=weapon_confidence_threshold
            )
        
        self.enable_tracking = enable_tracking
        self.track_manager = TrackManager(
            iou_threshold=0.3, 
            use_temporal_voting=use_temporal_voting,
            weapon_confidence_threshold=weapon_confidence_threshold
        )
        
        self.statistics = DetectionStatistics()
        
        # Track video-level processing
        self.current_video_tracks = []
        self.frame_count = 0
    
    def process_frame_with_tracking(self, frame, camera=None):
        """Processa frame com tracking de pessoas e detecção de armas"""
        self.frame_count += 1

        # Detecta COISAS com o YOLO
        results = self.model(frame, conf=self.confidence_threshold, verbose=False)

        detections = []
        weapon_detections = []
        weapon_bboxes = []
        distances = []
        position_data_list = []

        for result in results:
            for detection in result.boxes:
                class_id = int(detection.cls)
                class_name = self.model.names[class_id]

                # => FILTRAR APENAS PESSOAS <=
                if class_name != 'person':
                    continue

                bbox = detection.xyxy[0].cpu().numpy()
                x1, y1, x2, y2 = bbox
                w, h = x2 - x1, y2 - y1
                person_bbox = [x1, y1, w, h]
                detections.append(person_bbox)

                # Recorte da pessoa detectada
                person_crop = frame[int(y1):int(y2), int(x1):int(x2)]

                has_weapon = False
                weapon_conf = 0.0
                weapon_bbox_list = []

                # Executa detecção de armas apenas dentro do recorte da pessoa
                if self.enable_weapon_detection and person_crop.size > 0:
                    offset = (int(x1), int(y1)) if self.show_weapon_bbox else None
                    _, detections_info, _ = self.weapon_detector.detect_weapons(person_crop, offset)
                    has_weapon = len(detections_info) > 0
                    if has_weapon:
                        weapon_conf = detections_info[0]['confidence']
                        if self.show_weapon_bbox:
                            # passa informacao completa das deteccoes de arma
                            weapon_bbox_list = detections_info

                weapon_detections.append((has_weapon, weapon_conf))
                weapon_bboxes.append(weapon_bbox_list)

                # Estima distância (opcional)
                distance = None
                position_data = None
                if camera and h > 0:
                    AVERAGE_PERSON_HEIGHT_M = 1.7
                    detected_bbox = [x1, y1, w, h]

                    try:
                        x_utm, y_utm, lat, lon, bearing, distance = MonocularVision.monocular_vision_detection_method_2(
                            camera, AVERAGE_PERSON_HEIGHT_M, detected_bbox
                        )

                        position_data = {
                            'x_utm': x_utm,
                            'y_utm': y_utm,
                            'lat': lat,
                            'lon': lon,
                            'bearing': bearing
                        }
                    except Exception as e:
                        print(f"[WARN] Erro ao estimar distância: {e}")

                distances.append(distance)
                position_data_list.append(position_data)

        # Atualiza tracking
        if self.enable_tracking:
            tracks = self.track_manager.update(
                detections,
                weapon_detections,
                distances,
                weapon_bboxes if self.show_weapon_bbox else None,
                position_data_list
            )
        else:
            tracks = []
            for i, det in enumerate(detections):
                track = PersonTrack(
                    track_id=f"T{i}", 
                    use_temporal_voting=self.use_temporal_voting,
                    weapon_confidence_threshold=self.weapon_confidence_threshold
                )
                has_weapon, weapon_conf = weapon_detections[i]
                w_bboxes = weapon_bboxes[i] if self.show_weapon_bbox else []
                pos_data = position_data_list[i] if i < len(position_data_list) else None
                track.update(det, has_weapon, weapon_conf, distances[i], w_bboxes, pos_data)
                tracks.append(track)

        return frame, tracks
    
    def process_video_with_tracking(self, video_path, output_path=None, camera=None):
        """processa video completo com tracking"""
        print(f"Processing video with tracking: {video_path}")
        
        # reseta tracking para novo video
        self.track_manager.reset()
        self.frame_count = 0
        cap = cv2.VideoCapture(str(video_path))
        if not cap.isOpened():
            print(f"Error: Could not open video {video_path}")
            return None
        
        fps = int(cap.get(cv2.CAP_PROP_FPS))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        
        print(f"Video: {width}x{height} @ {fps}fps, {total_frames} frames")
        
        out = None
        if output_path:
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(str(output_path), fourcc, fps, (width, height))
        
        stats = {
            'total_frames': 0,
            'frames_with_people': 0,
            'unique_tracks': set(),
            'frames_with_weapons': 0,
            'max_people_in_frame': 0,
            'track_durations': {}
        }
        
        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                
                annotated_frame, tracks = self.process_frame_with_tracking(frame, camera)
                
                stats['total_frames'] += 1
                if tracks:
                    stats['frames_with_people'] += 1
                    stats['max_people_in_frame'] = max(
                        stats['max_people_in_frame'], 
                        len([t for t in tracks if not t.lost])
                    )
                    
                    for track in tracks:
                        stats['unique_tracks'].add(track.id)
                        if track.has_weapon():
                            stats['frames_with_weapons'] += 1
                            break
                        
                        if track.id not in stats['track_durations']:
                            stats['track_durations'][track.id] = 0
                        stats['track_durations'][track.id] += 1
                
                if out:
                    out.write(annotated_frame)
                
                if stats['total_frames'] % 30 == 0:
                    print(f"  Processed {stats['total_frames']}/{total_frames} frames...", end='\r')
        
        finally:
            cap.release()
            if out:
                out.release()
        
        print(f"\nCompleted! Processed {stats['total_frames']} frames")
        
        stats['unique_people_count'] = len(stats['unique_tracks'])
        stats['avg_track_duration'] = (
            sum(stats['track_durations'].values()) / len(stats['track_durations'])
            if stats['track_durations'] else 0
        )
        
        return stats
    
    def reset_tracking(self):
        """reseta estado do tracking"""
        self.track_manager.reset()
        self.frame_count = 0
