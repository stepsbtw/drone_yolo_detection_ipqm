from .converter import Converter
import math

class MonocularVision:
    """metodos de visao monocular para estimativa de distancia"""
     
    @staticmethod
    def monocular_vision_detection_method_1(alpha, bearing, height):
        """metodo 1: calculo simples baseado em angulo e altura"""
        if alpha == 0:
            return b, math.nan
        if alpha <= 90:
            alpha = 90 - alpha
        else:
            if alpha <= 180:
                alpha = 180 - alpha
            else:
                if alpha < 270:
                    alpha = 270 - alpha
                else:
                    alpha = 360 - alpha
        alpha = math.radians(alpha)
        d = height / math.tan(alpha)
        b = bearing
        return b, d
    

    @staticmethod
    def monocular_vision_detection_method_2(camera, real_height, detected_bbox):
        """
        metodo 2 (dcm): calculo considerando posicao no frame e hfov
        retorna: (x_utm, y_utm, lat, lon, bearing, distance)
        
        Args:
            camera: Camera object with focal_length_px and sensor specs
            real_height: Real height of object in meters (e.g., 1.7m for person)
            detected_bbox: [x, y, width, height] in pixels
        """
        pixel_width = detected_bbox[2]
        pixel_height = detected_bbox[3]
        x_center_pixel = detected_bbox[0] + (pixel_width / 2)
        x_center_frame = camera.sensor_width_resolution / 2
        
        # calcula offset horizontal em relacao ao centro
        fator = (x_center_pixel - x_center_frame) / (camera.sensor_width_resolution / 2)
        diff_degrees = fator * (camera.hfov / 2)
        
        # ajusta bearing baseado no offset (usa bearing da camera se disponivel, senao 0)
        camera_bearing = getattr(camera, 'bearing', 0) or 0
        new_bearing = (camera_bearing + diff_degrees) % 360
        
        # calcula distancia usando focal length em pixels
        new_distance = (real_height * camera.focal_length_px) / pixel_height
        
        # converte para coordenadas utm e geograficas (se camera tiver posicao)
        camera_x = getattr(camera, 'x', 0) or 0
        camera_y = getattr(camera, 'y', 0) or 0
        
        new_position_x, new_position_y = Converter.polar_to_xy(camera_x, camera_y, new_bearing, new_distance)
        lat, lon = Converter.xy_to_geo(new_position_x, new_position_y)
        
        return new_position_x, new_position_y, lat, lon, new_bearing, new_distance