# Drone People Detector - Library

A Python library for detecting people and weapons in drone footage using YOLO models with Kalman filter tracking.

## Features

- 🎯 **Person Detection** using YOLO11n
- 🔫 **Weapon Detection** using YOLOv8
- 📍 **Multi-Object Tracking** with Kalman filtering
- 📏 **Distance Estimation** - Two methods available:
  - **Pinhole Camera Model**: Simple and fast distance estimation
  - **DCM (Distance Calculation Method)**: Advanced method with GPS coordinates, bearing, and HFOV consideration
- 🎨 **Weapon Classification** with temporal voting
- 🌍 **Geographic Coordinates** (when using DCM method)

## Installation

### From Wheel Package

```bash
pip install dist/drone_people_detector-1.0.0-py3-none-any.whl
```

### Build from Source

```bash
./build_library.sh
pip install dist/drone_people_detector-1.0.0-py3-none-any.whl
```

## Project Structure

```
drone_yolo_detection_ipqm/
├── build_library.sh              # Build script
├── pyproject.toml                # Package configuration
├── requirements.txt              # Dependencies
├── dist/                         # Built packages
│   └── drone_people_detector-1.0.0-py3-none-any.whl
├── models/                       # YOLO models
│   ├── people/yolo11n.pt        # Person detection (5.4MB)
│   └── weapons/yolov8guns.pt    # Weapon detection (6.0MB)
└── src/
    ├── drone_people_detector/   # Library code
    │   ├── __init__.py
    │   ├── drone_people_detector.py
    │   └── core/
    │       ├── enhanced_detector.py
    │       ├── estimation.py
    │       └── weapon_detector.py
    ├── new/                      # Tracking module (PersonTrack)
    └── inputs/                   # Test videos
```

## Dependencies

- Python >= 3.10
- opencv-python >= 4.5.0
- numpy >= 1.20.0
- ultralytics >= 8.0.0
- torch >= 1.11.0
- torchvision >= 0.12.0
- Pillow >= 8.0.0
- filterpy >= 1.4.5
- pyproj >= 3.0.0

## Building the Package

```bash
./build_library.sh
```

Creates wheel package in `dist/` ready for installation.

## Usage

### Basic Usage (Pinhole Method)

```python
from drone_people_detector import DronePeopleDetector
from drone_people_detector.core.estimation import Camera

# camera simples (metodo pinhole)
camera = Camera(
    sensor_width_mm=6.4,
    sensor_height_mm=4.8,
    focal_35mm_mm=25.6,
    image_width_px=1920,
    image_height_px=1080
)

detector = DronePeopleDetector(
    model_path='models/people/yolo11n.pt',
    confidence_threshold=0.5,
    enable_weapon_detection=True,
    enable_tracking=True
)

# processar frame
annotated_frame, tracks = detector.process_frame_with_tracking(frame, camera=camera)

for track in tracks:
    print(f"Track {track.id}: distance={track.distance:.1f}m")
```

### Advanced Usage (DCM Method with GPS)

```python
# camera com dcm (coordenadas geograficas + bearing)
camera_dcm = Camera(
    sensor_width_mm=6.4,
    sensor_height_mm=4.8,
    focal_35mm_mm=25.6,
    image_width_px=1920,
    image_height_px=1080,
    hfov=62.2,      # campo de visao horizontal (graus)
    bearing=45,     # direcao da camera (norte=0, leste=90)
    lat=-23.5505,   # latitude da camera
    lon=-46.6333    # longitude da camera
)

# detector usa automaticamente dcm quando hfov disponivel
annotated_frame, tracks = detector.process_frame_with_tracking(frame, camera=camera_dcm)

# para obter coordenadas geograficas:
for track in tracks:
    if track.bbox:
        x, y, lat, lon, bearing, distance = camera_dcm.estimate_distance_dcm(track.bbox)
        print(f"Track {track.id}:")
        print(f"  Distance: {distance:.1f}m")
        print(f"  Bearing: {bearing:.1f}°")
        print(f"  GPS: {lat:.6f}, {lon:.6f}")
```

See `examples/dcm_usage_example.py` for complete examples.
See `drone_service` project for video processing examples.

## Distance Estimation Methods

### 1. Pinhole Camera Model (Default)
- Simple and fast
- Requires only pixel height
- Returns: distance in meters

### 2. DCM (Distance Calculation Method)
- More sophisticated and accurate
- Considers horizontal position in frame
- Accounts for camera bearing and HFOV
- Returns: distance + GPS coordinates (lat/lon) + bearing
- Ideal for: Moving drones, PTZ cameras, geolocation requirements

## License

See LICENSE file.
