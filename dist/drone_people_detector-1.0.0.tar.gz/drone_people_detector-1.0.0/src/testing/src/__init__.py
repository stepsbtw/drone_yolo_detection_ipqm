"""
YOLOv11 People Detection Pipeline

A simple and organized pipeline for detecting people in images using YOLOv11.
"""

__version__ = "1.0.0"